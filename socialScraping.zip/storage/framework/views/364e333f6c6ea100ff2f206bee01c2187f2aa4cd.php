<?php $__env->startSection('title', 'search'); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('youtube.results')); ?>" method="get" class="mb-5 mt-5">
        <div class="row">
            <div class="col-sm-8 form-group">
                <input type="text" class="form-control" name="search" placeholder="Search .........." >

            </div>
            <div class="col-sm-4">
                <input type="submit" value="Search" class="btn btn-success">
            </div>
        </div>
    </form>

    <div class="row">

        <?php $__currentLoopData = $videoLists->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4">
                <a href="<?php echo e(route('youtube.watch', $item->id->videoId)); ?>">
                    <div class="card mb-4">
                        <img src="<?php echo e($item->snippet->thumbnails->medium->url); ?>" class="img-fluid" alt="">
                        <div class="card-body">
                            <h5 class="card-titled"><?php echo e(\Illuminate\Support\Str::limit($item->snippet->title, $limit = 50, $end = ' ...')); ?></h5>
                        </div>
                        <div class="card-footer text-muted">
                            Published at <?php echo e(date('d M Y', strtotime($item->snippet->publishTime))); ?>

                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socialScraping\resources\views/youtube/index.blade.php ENDPATH**/ ?>