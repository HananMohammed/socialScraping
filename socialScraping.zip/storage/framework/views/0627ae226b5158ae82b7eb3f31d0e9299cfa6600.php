<?php $__env->startSection('title', 'HomePage'); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .text{
            text-transform: uppercase;
            background: linear-gradient(to right, #30CFD0 0%, #330867 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-size: 60px;
            font-weight: 800;
            font-family: sans-serif;
        }
    </style>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h3 class="text mt-5">Social Media Scraping </h3>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socialScraping\resources\views/index.blade.php ENDPATH**/ ?>