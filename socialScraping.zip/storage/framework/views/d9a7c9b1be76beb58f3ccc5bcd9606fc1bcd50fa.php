<?php $__env->startSection('title', 'Channel Data'); ?>
<?php $__env->startSection('style'); ?>

    <style>
        #content,
        #authorize-button,
        #signout-button {
            display: none
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <p class="mt-5">Log In With Google</p>
            <button class="btn red" id="authorize-button">Log In</button>
            <button class="btn red" id="signout-button">Log Out</button>
            <br>
            <div id="content">
                <div class="row">
                    <div class="col s6">
                        <form id="channel-form">
                            <div class="input-field col s6">
                                <input type="text" placeholder="Enter Channel Name" id="channel-input">
                                <input type="submit" value="Get Channel Data" class="btn grey">
                            </div>
                        </form>
                    </div>
                    <div id="channel-data" class="col s6"></div>
                </div>
                <div class="row" id="video-container"></div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/main.js')); ?>"></script>
    <script async defer src="https://apis.google.com/js/api.js" onload="this.onload=function(){};handleClientLoad()" onreadystatechange="if (this.readyState === 'complete') this.onload()"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socialScraping\resources\views/youtube/channel/index.blade.php ENDPATH**/ ?>