<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col">
        <?php $__currentLoopData = $videoLists->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row mb-3">
                <a href="<?php echo e(route('youtube.watch', $item->id->videoId)); ?>" style="display: contents">
                    <div class="col-4">
                        <img src="<?php echo e($item->snippet->thumbnails->medium->url); ?>" alt="" class="img-fluid">
                    </div>
                    <div class="col-8">
                        <h5><?php echo e(\Illuminate\Support\Str::limit($item->snippet->title, $limit = 150, $end = ' ...')); ?></h5>
                        <p class="text-muted">Published
                            at <?php echo e(date('d M Y', strtotime($item->snippet->publishTime))); ?></p>
                        <p><?php echo e(\Illuminate\Support\Str::limit($item->snippet->description, $limit = 300, $end = ' ...')); ?></p>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\socialScraping\resources\views/youtube/results.blade.php ENDPATH**/ ?>